﻿
namespace fish
{
    partial class Form1
    {
        /// <summary>
        ///  Required desiner variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openDialog = new System.Windows.Forms.OpenFileDialog();
            this.open_file = new System.Windows.Forms.Button();
            this.open_text = new System.Windows.Forms.Label();
            this.openStats = new System.Windows.Forms.OpenFileDialog();
            this.open_second_file = new System.Windows.Forms.Button();
            this.fish_info = new System.Windows.Forms.Label();
            this.confirm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // openDialog
            // 
            this.openDialog.FileName = "openFileDialog1";
            // 
            // open_file
            // 
            this.open_file.Location = new System.Drawing.Point(19, 513);
            this.open_file.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.open_file.Name = "open_file";
            this.open_file.Size = new System.Drawing.Size(331, 183);
            this.open_file.TabIndex = 0;
            this.open_file.Text = "Открыть файл";
            this.open_file.UseVisualStyleBackColor = true;
            this.open_file.Click += new System.EventHandler(this.button1_pressing);
            // 
            // open_text
            // 
            this.open_text.AutoSize = true;
            this.open_text.BackColor = System.Drawing.SystemColors.ControlDark;
            this.open_text.Location = new System.Drawing.Point(19, 459);
            this.open_text.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.open_text.Name = "open_text";
            this.open_text.Size = new System.Drawing.Size(331, 28);
            this.open_text.TabIndex = 1;
            this.open_text.Text = "Загрузить значения о температуре";
            this.open_text.Click += new System.EventHandler(this.label1_pressing);
            // 
            // openStats
            // 
            this.openStats.FileName = "openFileDialog1";
            // 
            // open_second_file
            // 
            this.open_second_file.Location = new System.Drawing.Point(19, 230);
            this.open_second_file.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.open_second_file.Name = "open_second_file";
            this.open_second_file.Size = new System.Drawing.Size(311, 181);
            this.open_second_file.TabIndex = 2;
            this.open_second_file.Text = "Открыть файл";
            this.open_second_file.UseVisualStyleBackColor = true;
            this.open_second_file.Click += new System.EventHandler(this.button1_pressing_1);
            // 
            // fish_info
            // 
            this.fish_info.AutoSize = true;
            this.fish_info.BackColor = System.Drawing.SystemColors.ControlDark;
            this.fish_info.Location = new System.Drawing.Point(19, 164);
            this.fish_info.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.fish_info.Name = "fish_info";
            this.fish_info.Size = new System.Drawing.Size(303, 28);
            this.fish_info.TabIndex = 3;
            this.fish_info.Text = "Загрузить информацию о рыбе";
            // 
            // confirm
            // 
            this.confirm.Location = new System.Drawing.Point(368, 713);
            this.confirm.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(206, 190);
            this.confirm.TabIndex = 4;
            this.confirm.Text = "OK";
            this.confirm.UseVisualStyleBackColor = true;
            this.confirm.Click += new System.EventHandler(this.confirm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(154, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 28);
            this.label1.TabIndex = 5;
            this.label1.Text = "узнать информацию о товаре";
            this.label1.Click += new System.EventHandler(this.label1_pressing_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 926);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.fish_info);
            this.Controls.Add(this.open_second_file);
            this.Controls.Add(this.open_text);
            this.Controls.Add(this.open_file);
            this.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openDialog;
        private System.Windows.Forms.Button open_file;
        private System.Windows.Forms.Label open_text;
        private System.Windows.Forms.OpenFileDialog openStats;
        private System.Windows.Forms.Button open_second_file;
        private System.Windows.Forms.Label fish_info;
        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.Label label1;
    }
}

