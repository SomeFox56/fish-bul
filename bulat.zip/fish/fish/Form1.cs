﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fish
{
    public partial class Form1 : Form
    {       
        DateTime current_date;
        DateTime start_date;
        DateTime limit = new DateTime(2000, 1, 1, 0, 0, 0);
        DateTime min_Limit = new DateTime(2000, 1, 1, 0, 0, 0);
        DateTime max_Limit = new DateTime(2000, 1, 1, 0, 0, 0);
        string date_time;
        string[] temps;
        string fish_name;
        string[] max_temperature;
        string[] min_temperature;
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_pressing(object sender, EventArgs e)
        {           
            openDialog.ShowDialog();
            string filename = openDialog.FileName;
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(filename, false);                 
                date_time = sw.ReadLine();
                start_date = DateTime.Parse(date_time);
                current_date = start_date;               
                temps = sw.ReadLine().Split(" ");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Ошибка при вводе данных");
            }
            finally
            {                
                sw.Close();               
            }
        }      

        private void button1_pressing_1(object sender, EventArgs e)
        {           
            openDialog.ShowDialog();
            string filename = openDialog.FileName;
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(filename, false);
                fish_name = sw.ReadLine();
                max_temperature = sw.ReadLine().Split(" ");
                string min_temperature_line = sw.ReadLine();
                if (min_temperature_line == null)
                {
                    min_temperature = null;
                }
                else
                {
                    min_temperature = min_temperature_line.Split(" ");
                }               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                sw.Close();
            }
        }

        private void confirm_Click(object sender, EventArgs e)
        {
            limit = new DateTime(2000, 1, 1, 0, 0, 0);
            min_Limit = new DateTime(2000, 1, 1, 0, 0, 0);
            max_Limit = new DateTime(2000, 1, 1, 0, 0, 0);
            StreamWriter sw = null;
            try
            {
            sw = new StreamWriter("fishing.txt", false);                                   
            for (int i = 0; i < temps.Length; i++)
            {
                if(min_temperature != null)
                {
                        if (Convert.ToInt32(temps[i]) > Convert.ToInt32(max_temperature[0]))
                    {
                        sw.WriteLine($"{current_date:g}" + " " + temps[i] + " " + max_temperature[0] + " " + (Convert.ToInt32(max_temperature[0]) - Convert.ToInt32(temps[i])));
                        max_Limit = max_Limit.AddMinutes(10);
                     }
                        if (Convert.ToInt32(temps[i]) < Convert.ToInt32(min_temperature[0]))
                    {
                        sw.WriteLine($"{current_date:g}" + " " + temps[i] + " "+min_temperature[0]+" " + (Convert.ToInt32(min_temperature[0]) - Convert.ToInt32(temps[i]) ));
                        limit = limit.AddMinutes(10);
                        min_Limit = min_Limit.AddMinutes(10);
                    }
                    
                }
                else
                {
                    if (Convert.ToInt32(temps[i]) > Convert.ToInt32(max_temperature[0]))
                    {
                        sw.WriteLine($"{current_date:g}" + " " + temps[i] + " " + max_temperature[0] + " " + (Convert.ToInt32(max_temperature[0]) - Convert.ToInt32(temps[i])));
                        limit = limit.AddMinutes(10);
                        max_Limit = max_Limit.AddMinutes(10);
                    }
                }
                current_date = current_date.AddMinutes(10);
            }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.WriteLine("Повышение порога" + $"{limit:t}");
                    sw.Close();
                }
            }
        }

        private void label1_pressing_1(object sender, EventArgs e)
        {

        }
        private void label1_pressing(object sender, EventArgs e)
        {

        }
    }
}
